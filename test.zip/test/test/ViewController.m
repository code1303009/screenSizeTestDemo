//
//  ViewController.m
//  test
//
//  Created by martin on 2021/11/15.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    // 获取屏幕尺寸
    CGSize screenSize = [UIScreen mainScreen].bounds.size;
    NSLog(@"======屏幕尺寸=======");
    NSLog(@"宽： %f, 高 ： %f",screenSize.width,screenSize.height);
    
    // 获取window窗口
    UIWindow *window = [[UIApplication sharedApplication].windows firstObject];
    // 获取安全区域top高度,即状态条高度
    NSLog(@"状态栏高度： %f",window.safeAreaInsets.top);
    // 获取导航条高度
    UINavigationController *nav = [[UINavigationController alloc] init];
    NSLog(@"导航栏高度 ： %f",nav.navigationBar.frame.size.height);
    
}



@end
