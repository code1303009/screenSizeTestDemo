//
//  SceneDelegate.h
//  test
//
//  Created by martin on 2021/11/15.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

